// Place your content here🐶
var message = "Hello World!";
console.log(message);
// @ts-ignore
$(".math").latex();
// @ts-ignore
$(".imath").latex();
